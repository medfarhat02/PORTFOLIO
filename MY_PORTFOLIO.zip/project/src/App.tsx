import React, { useState, useEffect } from 'react';
import { 
  Menu, 
  X, 
  Home, 
  User, 
  Code, 
  GraduationCap, 
  Briefcase, 
  FolderOpen, 
  Mail,
  MapPin,
  Phone,
  Linkedin,
  Github,
  Shield,
  Network,
  Database,
  Terminal,
  Server,
  Monitor,
  FileText,
  ChevronDown,
  ExternalLink
} from 'lucide-react';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'skills', 'education', 'experience', 'projects', 'contact'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      if (current) {
        setActiveSection(current);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const navigation = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'about', label: 'About', icon: User },
    { id: 'skills', label: 'Skills', icon: Code },
    { id: 'education', label: 'Education', icon: GraduationCap },
    { id: 'experience', label: 'Experience', icon: Briefcase },
    { id: 'projects', label: 'Projects', icon: FolderOpen },
    { id: 'contact', label: 'Contact', icon: Mail },
  ];

  const skills = {
    cybersecurity: [
      { name: 'Penetration Testing', level: 85 },
      { name: 'Vulnerability Assessment', level: 80 },
      { name: 'Nmap', level: 90 },
      { name: 'Bettercap', level: 75 },
    ],
    networking: [
      { name: 'Router/Switch Configuration', level: 85 },
      { name: 'VPNs', level: 80 },
      { name: 'Firewalls', level: 85 },
      { name: 'Network Security', level: 80 },
    ],
    programming: [
      { name: 'Python', level: 85 },
      { name: 'SQL', level: 80 },
    ],
    tools: [
      { name: 'Linux (Ubuntu, Kali)', level: 90 },
      { name: 'Windows Server', level: 85 },
      { name: 'VMware', level: 80 },
      { name: 'GNS3', level: 85 },
      { name: 'Packet Tracer', level: 90 },
      { name: 'VSCode', level: 85 },
      { name: 'Git', level: 80 },
    ],
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <h1 className="text-xl font-bold text-blue-400">Mohammed Farhat</h1>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navigation.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => scrollToSection(item.id)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeSection === item.id
                        ? 'bg-blue-600 text-white'
                        : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-gray-800">
              {navigation.map((item) => (
                <button
                  key={item.id}
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors flex items-center space-x-2 ${
                    activeSection === item.id
                      ? 'bg-blue-600 text-white'
                      : 'text-gray-300 hover:bg-gray-700 hover:text-white'
                  }`}
                >
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-blue-900 to-gray-900 pt-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <div className="w-32 h-32 mx-auto mb-8 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 p-1">
              <div className="w-full h-full rounded-full bg-gray-800 flex items-center justify-center">
                <Shield className="h-16 w-16 text-blue-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Mohammed Farhat
            </h1>
            <h2 className="text-xl md:text-2xl text-gray-300 mb-6">
              IT Systems & Network Technician
            </h2>
            <p className="text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Passionate about IT systems, networks, and cybersecurity. Dedicated to improving infrastructure 
              performance and security through innovative solutions and continuous learning.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => scrollToSection('contact')}
              className="px-8 py-3 bg-blue-600 hover:bg-blue-700 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
            >
              <Mail className="h-5 w-5" />
              <span>Get In Touch</span>
            </button>
            <button
              onClick={() => scrollToSection('about')}
              className="px-8 py-3 border border-gray-600 hover:border-gray-500 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
            >
              <ChevronDown className="h-5 w-5" />
              <span>Learn More</span>
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">About Me</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Driven by curiosity and passion for technology
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <div className="bg-gray-700/50 p-8 rounded-xl backdrop-blur-sm">
                <h3 className="text-2xl font-semibold mb-6 text-blue-400">Professional Focus</h3>
                <p className="text-gray-300 mb-6 leading-relaxed">
                  I'm a dedicated IT Systems and Network Technician with a deep passion for cybersecurity. 
                  My expertise lies in building secure, efficient network infrastructures and conducting 
                  thorough security assessments to protect organizational assets.
                </p>
                <p className="text-gray-300 leading-relaxed">
                  I thrive on solving complex technical challenges and continuously expanding my knowledge 
                  in emerging technologies and security methodologies.
                </p>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-blue-600/10 to-purple-600/10 p-6 rounded-xl border border-blue-500/20">
                <h4 className="text-xl font-semibold mb-4 flex items-center">
                  <User className="h-6 w-6 mr-2 text-blue-400" />
                  Core Strengths
                </h4>
                <ul className="space-y-2 text-gray-300">
                  <li>• Strong analytical and problem-solving abilities</li>
                  <li>• Excellent team collaboration and communication</li>
                  <li>• High adaptability to new technologies</li>
                  <li>• Continuous self-improvement mindset</li>
                </ul>
              </div>

              <div className="bg-gradient-to-r from-green-600/10 to-blue-600/10 p-6 rounded-xl border border-green-500/20">
                <h4 className="text-xl font-semibold mb-4 flex items-center">
                  <Network className="h-6 w-6 mr-2 text-green-400" />
                  Languages
                </h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">Arabic</span>
                    <span className="text-green-400 font-medium">Native</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">English</span>
                    <span className="text-blue-400 font-medium">Good</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">French</span>
                    <span className="text-purple-400 font-medium">Intermediate</span>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-r from-purple-600/10 to-pink-600/10 p-6 rounded-xl border border-purple-500/20">
                <h4 className="text-xl font-semibold mb-4 flex items-center">
                  <Monitor className="h-6 w-6 mr-2 text-purple-400" />
                  Interests
                </h4>
                <div className="grid grid-cols-2 gap-2 text-gray-300">
                  <span>• Technology</span>
                  <span>• Football</span>
                  <span>• Fitness</span>
                  <span>• Self-education</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Technical Skills</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Comprehensive expertise across cybersecurity, networking, and system administration
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8">
            {/* Cybersecurity Skills */}
            <div className="bg-gradient-to-br from-red-900/20 to-red-700/20 p-8 rounded-xl border border-red-500/30">
              <div className="flex items-center mb-6">
                <Shield className="h-8 w-8 text-red-400 mr-3" />
                <h3 className="text-2xl font-semibold">Cybersecurity</h3>
              </div>
              <div className="space-y-4">
                {skills.cybersecurity.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-300">{skill.name}</span>
                      <span className="text-red-400">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-red-500 to-red-400 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Networking Skills */}
            <div className="bg-gradient-to-br from-blue-900/20 to-blue-700/20 p-8 rounded-xl border border-blue-500/30">
              <div className="flex items-center mb-6">
                <Network className="h-8 w-8 text-blue-400 mr-3" />
                <h3 className="text-2xl font-semibold">Networking</h3>
              </div>
              <div className="space-y-4">
                {skills.networking.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-300">{skill.name}</span>
                      <span className="text-blue-400">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-blue-500 to-blue-400 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Programming Skills */}
            <div className="bg-gradient-to-br from-green-900/20 to-green-700/20 p-8 rounded-xl border border-green-500/30">
              <div className="flex items-center mb-6">
                <Code className="h-8 w-8 text-green-400 mr-3" />
                <h3 className="text-2xl font-semibold">Programming</h3>
              </div>
              <div className="space-y-4">
                {skills.programming.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-300">{skill.name}</span>
                      <span className="text-green-400">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-green-400 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Tools & Platforms */}
            <div className="bg-gradient-to-br from-purple-900/20 to-purple-700/20 p-8 rounded-xl border border-purple-500/30">
              <div className="flex items-center mb-6">
                <Terminal className="h-8 w-8 text-purple-400 mr-3" />
                <h3 className="text-2xl font-semibold">Tools & Platforms</h3>
              </div>
              <div className="space-y-4">
                {skills.tools.map((skill, index) => (
                  <div key={index}>
                    <div className="flex justify-between mb-2">
                      <span className="text-gray-300">{skill.name}</span>
                      <span className="text-purple-400">{skill.level}%</span>
                    </div>
                    <div className="w-full bg-gray-700 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-purple-500 to-purple-400 h-2 rounded-full transition-all duration-1000"
                        style={{ width: `${skill.level}%` }}
                      ></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Office Tools */}
          <div className="mt-8">
            <div className="bg-gradient-to-r from-gray-800 to-gray-700 p-6 rounded-xl">
              <div className="flex items-center mb-4">
                <FileText className="h-6 w-6 text-gray-400 mr-3" />
                <h3 className="text-xl font-semibold">Office Tools</h3>
              </div>
              <div className="flex flex-wrap gap-3">
                <span className="px-4 py-2 bg-blue-600/20 text-blue-300 rounded-full border border-blue-500/30">Microsoft Word</span>
                <span className="px-4 py-2 bg-green-600/20 text-green-300 rounded-full border border-green-500/30">Microsoft Excel</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Education & Certifications</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Academic foundation and professional certifications
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Education */}
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <GraduationCap className="h-7 w-7 text-blue-400 mr-3" />
                Education
              </h3>
              
              <div className="bg-gradient-to-r from-blue-600/10 to-purple-600/10 p-6 rounded-xl border border-blue-500/20">
                <h4 className="text-xl font-semibold text-blue-400 mb-2">
                  Technician Specialized in Systems and Networks
                </h4>
                <p className="text-gray-300 mb-2">ISTA (Institut Spécialisé de Technologie Appliquée)</p>
                <p className="text-gray-400">Comprehensive training in IT systems administration and network management</p>
              </div>

              <div className="bg-gradient-to-r from-green-600/10 to-blue-600/10 p-6 rounded-xl border border-green-500/20">
                <h4 className="text-xl font-semibold text-green-400 mb-2">
                  Baccalauréat in Experimental Sciences
                </h4>
                <p className="text-gray-300 mb-2">Physics & Chemistry Specialization</p>
                <p className="text-gray-400">Strong foundation in scientific methodology and analytical thinking</p>
              </div>
            </div>

            {/* Certifications */}
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold mb-6 flex items-center">
                <Shield className="h-7 w-7 text-green-400 mr-3" />
                Certifications
              </h3>
              
              <div className="space-y-4">
                <div className="bg-gradient-to-r from-red-600/10 to-orange-600/10 p-6 rounded-xl border border-red-500/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-lg font-semibold text-red-400">Cybersecurity Introduction</h4>
                      <p className="text-gray-400">Foundation in cybersecurity principles</p>
                    </div>
                    <Shield className="h-8 w-8 text-red-400" />
                  </div>
                </div>

                <div className="bg-gradient-to-r from-blue-600/10 to-cyan-600/10 p-6 rounded-xl border border-blue-500/20">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-lg font-semibold text-blue-400">Computer Hardware Basics</h4>
                      <p className="text-gray-400">Hardware components and troubleshooting</p>
                    </div>
                    <Server className="h-8 w-8 text-blue-400" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Professional Experience</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Hands-on experience in real-world IT environments
            </p>
          </div>

          <div className="space-y-8">
            <div className="bg-gradient-to-r from-blue-900/20 to-purple-900/20 p-8 rounded-xl border border-blue-500/30">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-semibold text-blue-400 mb-2">IT Systems Intern</h3>
                  <p className="text-xl text-gray-300">Menara Prefa</p>
                </div>
                <div className="text-gray-400 mt-2 md:mt-0">
                  <span className="bg-blue-600/20 px-3 py-1 rounded-full">Jan 2025 - Feb 2025</span>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Upcoming internship opportunity to apply theoretical knowledge in a practical business environment, 
                focusing on IT systems maintenance, network troubleshooting, and cybersecurity best practices.
              </p>
            </div>

            <div className="bg-gradient-to-r from-green-900/20 to-blue-900/20 p-8 rounded-xl border border-green-500/30">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                <div>
                  <h3 className="text-2xl font-semibold text-green-400 mb-2">IT Support Intern</h3>
                  <p className="text-xl text-gray-300">Direction Générale des Impôts</p>
                </div>
                <div className="text-gray-400 mt-2 md:mt-0">
                  <span className="bg-green-600/20 px-3 py-1 rounded-full">May 2024</span>
                </div>
              </div>
              <p className="text-gray-300 leading-relaxed">
                Gained valuable experience in government IT infrastructure, supporting daily operations, 
                system maintenance, and user technical support in a professional public sector environment.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Projects</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Personal and academic projects showcase
            </p>
          </div>

          <div className="text-center">
            <div className="bg-gradient-to-r from-gray-700 to-gray-600 p-12 rounded-xl border border-gray-500/30">
              <FolderOpen className="h-16 w-16 text-gray-400 mx-auto mb-6" />
              <h3 className="text-2xl font-semibold text-gray-300 mb-4">Coming Soon</h3>
              <p className="text-gray-400 max-w-2xl mx-auto leading-relaxed">
                This section will be updated with personal and academic projects, including network security 
                implementations, penetration testing reports, and system administration solutions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Get In Touch</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Ready to discuss opportunities or collaborate on projects
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-start">
            <div className="space-y-6">
              <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
                  <Mail className="h-6 w-6 text-blue-400" />
                  <div>
                    <p className="text-gray-300">Email</p>
                    <a href="mailto:farhatmohammed2212@gmail.com" className="text-blue-400 hover:text-blue-300">
                      farhatmohammed2212@gmail.com
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
                  <Phone className="h-6 w-6 text-green-400" />
                  <div>
                    <p className="text-gray-300">Phone</p>
                    <a href="tel:+212655069933" className="text-green-400 hover:text-green-300">
                      +212 655 069 933
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors">
                  <Linkedin className="h-6 w-6 text-blue-500" />
                  <div>
                    <p className="text-gray-300">LinkedIn</p>
                    <a 
                      href="https://linkedin.com/in/mohammed-farhat-a55b49254" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-400 flex items-center"
                    >
                      Mohammed Farhat <ExternalLink className="h-4 w-4 ml-1" />
                    </a>
                  </div>
                </div>

                <div className="flex items-center space-x-4 p-4 bg-gray-800 rounded-lg">
                  <MapPin className="h-6 w-6 text-red-400" />
                  <div>
                    <p className="text-gray-300">Location</p>
                    <p className="text-red-400">El Kelaa des Sraghna, Morocco</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-blue-900/20 to-purple-900/20 p-8 rounded-xl border border-blue-500/30">
              <h3 className="text-2xl font-semibold mb-6">Let's Connect</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                I'm always interested in discussing new opportunities, sharing knowledge about cybersecurity 
                and networking, or collaborating on interesting projects. Feel free to reach out!
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Shield className="h-5 w-5 text-blue-400" />
                  <span className="text-gray-300">Cybersecurity Consulting</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Network className="h-5 w-5 text-green-400" />
                  <span className="text-gray-300">Network Infrastructure</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Code className="h-5 w-5 text-purple-400" />
                  <span className="text-gray-300">Technical Collaboration</span>
                </div>
              </div>

              <div className="mt-8">
                <a
                  href="mailto:farhatmohammed2212@gmail.com"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 px-6 py-3 rounded-lg font-medium transition-all flex items-center justify-center space-x-2"
                >
                  <Mail className="h-5 w-5" />
                  <span>Send Email</span>
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 border-t border-gray-700 py-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-gray-400">
              © 2025 Mohammed Farhat. Built with passion for technology and security.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;